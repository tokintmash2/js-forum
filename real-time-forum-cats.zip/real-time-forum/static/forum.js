// Get navbar
const catHeader = document.getElementsByClassName('category-header')[0];

// Get body
let body = document.getElementsByTagName('body')[0];

// Create category list
const list = document.createElement('div');
list.id = 'categoryList';
list.classList.add('categories-container');


// Insert the div right after the navbar
catHeader.insertAdjacentElement('afterend', list);

document.addEventListener('DOMContentLoaded', function () {
    fetch('/api/categories')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(categories => {
            categories.forEach(category => {
                const a = document.createElement('a');
                a.textContent = category.Name;
                a.href = `/category/${category.ID}`;
                list.appendChild(a);
            });
        })
        .catch(error => {
            console.error('Error loading the categories:', error);
            list.textContent = 'Failed to load categories.'; // Update text content directly on 'list'
        });
});


