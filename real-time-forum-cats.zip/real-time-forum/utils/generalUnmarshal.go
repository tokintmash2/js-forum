package utils

import "encoding/json"

func GenericUnmarshal(jsonStr string, target interface{}) error {
	return json.Unmarshal([]byte(jsonStr), target)
}
